﻿using Emp_Payment_App.Common_API;
using Emp_Payment_BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Emp_Payment_App.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            try
            {
                API obj = new API();
                Employee empObj = new Employee();
                if (obj.DepartmentList().ToList().Count > 0) 
                empObj.DeptList = obj.DepartmentList();
                if (obj.GenderList().ToList().Count > 0)
                empObj.GenderList = obj.GenderList();
                return View(empObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // POST: Employee
        [HttpPost]
        public ActionResult Index(Employee empObj)
        {
            try
            {
                string successMessage = string.Empty;
                string failureMessage = string.Empty;
                API obj = new API();
                    if (empObj.EmpId == 0)
                    {
                        successMessage = "Employee Information is added succesfully!";
                        failureMessage = "Employee Information cannot be added!";
                    }
                    else
                    {
                        successMessage = "Employee Information is updated succesfully!";
                        failureMessage = "Employee Information cannot be updated!";
                    }

                    var result = obj.AddUpdateEmployee(empObj);
                    if (result>0)
                        ViewBag.Message = successMessage;
                    else
                        ViewBag.Message = failureMessage;
                if (obj.DepartmentList().ToList().Count > 0)
                    empObj.DeptList = obj.DepartmentList();
                if (obj.GenderList().ToList().Count > 0)
                    empObj.GenderList = obj.GenderList();
                return View(empObj);
           }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // GET: Employee List
        [HttpGet]
        public ActionResult EmployeeList()
        {
            try
            {
                 API obj = new API();
                 Employee empObj = new Employee();
                if (obj.DepartmentList().ToList().Count > 0)
                    empObj.DeptList = obj.DepartmentList();
                if (obj.GenderList().ToList().Count > 0)
                    empObj.GenderList = obj.GenderList();
                if (obj.EmployeeList().ToList().Count > 0)
                    empObj.EmployeeList = obj.EmployeeList();

                empObj.EmployeeList = from emp in empObj.EmployeeList
                                      join dept in empObj.DeptList
                                      on emp.DeptId equals dept.DeptId
                                      join gender in empObj.GenderList
                                      on emp.GId equals gender.GId
                                      select new Employee
                                      {
                                          EmpId = emp.EmpId,
                                          EmpName = emp.EmpName,
                                          DeptName = dept.DeptName,
                                          GName = gender.GenderName,
                                          Salary = emp.Salary,
                                          Allowance = emp.Allowance,
                                          GrossSalary = emp.GrossSalary
                                      };
                return View("EmployeeList", empObj.EmployeeList);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public ActionResult GetEmployeeListBasedonFilter(string filter)
        {
            try
            {
                API obj = new API();
                Employee empObj = new Employee();
                if (obj.DepartmentList().ToList().Count > 0)
                    empObj.DeptList = obj.DepartmentList();
                if (obj.GenderList().ToList().Count > 0)
                    empObj.GenderList = obj.GenderList();
                if (obj.EmployeeList().ToList().Count > 0)
                    empObj.EmployeeList = obj.EmployeeList();

                if (!String.IsNullOrEmpty(filter))
                {
                    if (filter.ToLower() == "hp") { 
                        empObj.EmployeeList = highestSalary(empObj.EmployeeList);
                        empObj.EmployeeList = from emp in empObj.EmployeeList
                                          join dept in empObj.DeptList
                                                  on emp.DeptId equals dept.DeptId
                                          join gender in empObj.GenderList
                                          on emp.GId equals gender.GId
                                          select new Employee
                                          {
                                              EmpId = emp.EmpId,
                                              EmpName = emp.EmpName,
                                              DeptName = dept.DeptName,
                                              GName = gender.GenderName,
                                              Salary = emp.Salary,
                                              Allowance = emp.Allowance,
                                              GrossSalary = emp.GrossSalary
                                          };
                    }
                    else if (filter.ToLower() == "maxmin")
                    {
                        empObj.EmployeeList =highestlowestSalaryByDept(empObj.EmployeeList);
                        empObj.EmployeeList = from emp in empObj.EmployeeList
                                              join dept in empObj.DeptList
                                                      on emp.DeptId equals dept.DeptId
                                              join gender in empObj.GenderList
                                              on emp.GId equals gender.GId
                                              select new Employee
                                              {
                                                  EmpId = emp.EmpId,
                                                  EmpName = emp.EmpName,
                                                  DeptName = dept.DeptName,
                                                  GName = gender.GenderName,
                                                  Salary = emp.Salary,
                                                  Allowance = emp.Allowance,
                                                  GrossSalary = emp.GrossSalary
                                              };

                    }
                    else
                    {
                        empObj.EmployeeList = from emp in empObj.EmployeeList
                                              join dept in empObj.DeptList
                                                      on emp.DeptId equals dept.DeptId
                                              join gender in empObj.GenderList
                                              on emp.GId equals gender.GId
                                              select new Employee
                                              {
                                                  EmpId = emp.EmpId,
                                                  EmpName = emp.EmpName,
                                                  DeptName = dept.DeptName,
                                                  GName = gender.GenderName,
                                                  Salary = emp.Salary,
                                                  Allowance = emp.Allowance,
                                                  GrossSalary = emp.GrossSalary
                                              };
                    }
                }
                
                return View("EmployeeList", empObj.EmployeeList);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        [HttpGet]
        public ActionResult EmployeeGetById(int id)
        {
            try
            {
                if (id == 0)
                {
                    ViewBag.Message = "Employee Id cannot be null or 0";
                    return View();
                }
                API obj = new API();
                Employee empObj = new Employee();
                empObj = obj.EmployeeGetById(id);
                if (obj.DepartmentList().ToList().Count > 0)
                    empObj.DeptList = obj.DepartmentList();
                if (obj.GenderList().ToList().Count > 0)
                    empObj.GenderList = obj.GenderList();
                return View("Index", empObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public IEnumerable<Employee> highestSalary(IEnumerable<Employee> empList)
        {
            return empList.GroupBy(x => x.Salary).OrderByDescending(x => x.Key).FirstOrDefault();
        }
        public IEnumerable<Employee> highestlowestSalaryByDept(IEnumerable<Employee> empList)
        {
           
            var highSalemployeePerDept = empList.GroupBy(x => x.DeptId)
                 .Select(g => g.OrderByDescending(x => x.Salary).First());
            var lowSalemployeePerDept = empList.GroupBy(x => x.DeptId)
              .Select(g => g.OrderBy(x => x.Salary).First());
            var salary = highSalemployeePerDept.Union(lowSalemployeePerDept);
            return salary;
        }
    }
}