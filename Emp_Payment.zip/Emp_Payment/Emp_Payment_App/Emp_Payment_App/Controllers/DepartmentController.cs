﻿using Emp_Payment_App.Common_API;
using Emp_Payment_BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Emp_Payment_App.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department
        public ActionResult Index()
        {
            return View();
        }
        //POST: Department
        [HttpPost]
        public ActionResult Index(Department deptObj)
        {
            try
            { 
                if (ModelState.IsValid)
                {
                    API obj = new API();
                    var countList = obj.DepartmentList().Count();
                    if (countList == 0)
                    {
                        var result = obj.DepartmentAdd(deptObj);
                        if (result > 0)
                            ViewBag.Message = "Department Inserted Successfully!";
                        else
                            ViewBag.Message = "Cannot be Inserted";
                    }
                    else if (countList > 0)
                    {
                        var totalList = obj.DepartmentList().ToList().Where(x => x.DeptName == deptObj.DeptName).Count();
                        if (totalList > 0)
                            ViewBag.Message = "Department already exists.";
                        else
                        {
                            var results = obj.DepartmentAdd(deptObj);
                            if (results > 0)
                                ViewBag.Message = "Department Inserted Successfully!";
                            else
                                ViewBag.Message = "Cannot be Inserted";
                        }
                    }

                }  
                    return View();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}