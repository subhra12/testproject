﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace Emp_Payment_App.Common_API
{

        public class CommonAPI
        {
            public CommonAPI() { }

            public string Get(string ApiUrl)
            {
                var result = "";
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ConfigurationManager.AppSettings["ApiBaseUrl"]);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", "abcd");
                    var response = client.GetAsync(ApiUrl).Result;
                    // response.Wait();
                    if (response.IsSuccessStatusCode)
                    {
                        result = response.Content.ReadAsStringAsync().Result;
                    }

                }
                return result;
            }

            public string Post(string ApiUrl, object data)
            {
                string result = "";
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(ConfigurationManager.AppSettings["ApiBaseUrl"]);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", "token_user");
                    var response = client.PostAsync(ApiUrl, new StringContent(data.ToString(),Encoding.UTF8,
                                    "application/json")).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        result = response.Content.ReadAsStringAsync().Result;
                    }
                }
                return result;
            }

            //public string JsonPost(string ApiUrl, string Json)
            //{
            //    string result = "";
            //    using (var client = new HttpClient())
            //    {
            //        client.BaseAddress = new Uri(ConfigurationManager.AppSettings["ApiBaseUrl"]);
            //        client.DefaultRequestHeaders.Clear();
            //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", "abcd");
            //        var response = client.PostAsJsonAsync(ApiUrl, Json).Result;
            //        if (response.IsSuccessStatusCode)
            //        {
            //            result = response.Content.ReadAsStringAsync().Result;
            //        }
            //    }
            //    return result;
            //}
        
    }
}