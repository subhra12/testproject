﻿using Emp_Payment_BO;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Emp_Payment_App.Common_API
{
    public class API
    {
        CommonAPI cmnApi;
        public API()
        {
            cmnApi = new CommonAPI();
        }



        #region Department
        #region Department List
        public IEnumerable<Department> DepartmentList()
        {
            IEnumerable<Department> result = null;

            string response = "";
            try
            {
                response = cmnApi.Get("Department/DepartmentList");
                if (!string.IsNullOrEmpty(response))
                {
                    result = JsonConvert.DeserializeObject<IEnumerable<Department>>(response);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        public int DepartmentAdd(Department param)
        {
            int result = 0;

            string response = "";
            try
            {
                response = cmnApi.Post("Department/DepartmentAdd", JsonConvert.SerializeObject(param));
                if (!string.IsNullOrEmpty(response))
                {
                    result = JsonConvert.DeserializeObject<int>(response);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion
        #endregion

        #region Employee
        #region Employee List
        public IEnumerable<Employee> EmployeeList()
        {
            IEnumerable<Employee> result = null;

            string response = "";
            try
            {
                response = cmnApi.Get("Employee/EmployeeList");
                if (!string.IsNullOrEmpty(response))
                {
                    result = JsonConvert.DeserializeObject<IEnumerable<Employee>>(response);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        public Employee EmployeeGetById(int id)
        {
            Employee result = new Employee();

            string response = "";
            try
            {
                response = cmnApi.Post("Employee/EmployeeGetById", JsonConvert.SerializeObject(id));
                if (!string.IsNullOrEmpty(response))
                {
                    result = JsonConvert.DeserializeObject<Employee>(response);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        public int AddUpdateEmployee(object param)
        {
            int result = 0;

            string response = "";
            try
            {
                response = cmnApi.Post("Employee/AddUpdateEmployee", JsonConvert.SerializeObject(param));
                if (!string.IsNullOrEmpty(response))
                {
                    result = JsonConvert.DeserializeObject<int>(response);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion
        #endregion

        #region Gender
        public IEnumerable<Gender> GenderList()
        {
            IEnumerable<Gender> result = null;

            string response = "";
            try
            {
                response = cmnApi.Get("Gender/GenderList");
                if (!string.IsNullOrEmpty(response))
                {
                    result = JsonConvert.DeserializeObject<IEnumerable<Gender>>(response);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        #endregion

    }
}